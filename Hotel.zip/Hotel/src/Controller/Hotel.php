<?php

namespace App\Controller;

class Hotel
{
    public function homepage()
    {
            return new Response("Hallo");
        }

    }