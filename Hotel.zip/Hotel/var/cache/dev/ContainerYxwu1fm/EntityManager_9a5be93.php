<?php

namespace ContainerYxwu1fm;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder37a74 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer583b5 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties8e4c6 = [
        
    ];

    public function getConnection()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getConnection', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getMetadataFactory', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getExpressionBuilder', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'beginTransaction', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getCache', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getCache();
    }

    public function transactional($func)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'transactional', array('func' => $func), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'wrapInTransaction', array('func' => $func), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'commit', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->commit();
    }

    public function rollback()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'rollback', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getClassMetadata', array('className' => $className), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'createQuery', array('dql' => $dql), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'createNamedQuery', array('name' => $name), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'createQueryBuilder', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'flush', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'clear', array('entityName' => $entityName), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->clear($entityName);
    }

    public function close()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'close', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->close();
    }

    public function persist($entity)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'persist', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'remove', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'refresh', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'detach', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'merge', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getRepository', array('entityName' => $entityName), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'contains', array('entity' => $entity), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getEventManager', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getConfiguration', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'isOpen', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getUnitOfWork', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getProxyFactory', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'initializeObject', array('obj' => $obj), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'getFilters', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'isFiltersStateClean', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'hasFilters', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return $this->valueHolder37a74->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer583b5 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder37a74) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder37a74 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder37a74->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, '__get', ['name' => $name], $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        if (isset(self::$publicProperties8e4c6[$name])) {
            return $this->valueHolder37a74->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder37a74;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder37a74;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder37a74;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder37a74;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, '__isset', array('name' => $name), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder37a74;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder37a74;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, '__unset', array('name' => $name), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder37a74;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder37a74;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, '__clone', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        $this->valueHolder37a74 = clone $this->valueHolder37a74;
    }

    public function __sleep()
    {
        $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, '__sleep', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;

        return array('valueHolder37a74');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer583b5 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer583b5;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer583b5 && ($this->initializer583b5->__invoke($valueHolder37a74, $this, 'initializeProxy', array(), $this->initializer583b5) || 1) && $this->valueHolder37a74 = $valueHolder37a74;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder37a74;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder37a74;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
